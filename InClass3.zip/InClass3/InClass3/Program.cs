﻿/* In class 3
 * 
 * revision History
 * 
 * Sarav Kular, October 4, 2017
 */
using System;

namespace InClass3
{
    class Program
    {
        public static int ProductTwoIntegers(int firstInteger, int secondInteger)

        {
            int Product;
            Product = 0;
            Product = firstInteger * secondInteger;
            return Product;
        }
        public static int ProductThreeIntegers(int firstInteger, int secondInteger, int thirdInteger)

        {
            int Product;
            Product = 0;
            Product = firstInteger * secondInteger * thirdInteger;
            return Product;
        }
        public static int ProductFourIntegers(int firstInteger, int secondInteger, int thirdInteger, int fourthInteger)

        {
            int Product;
            Product = 0;
            Product = firstInteger * secondInteger * thirdInteger * fourthInteger;
            return Product;
        }
        public static void ProductDouble(double a, double b = 2, double c = 5, double d = 5)
        {
            Console.WriteLine((a * b * c * d));
        }
        static void Main(string[] args)
        {
           
                {
                    int number1;
                    int number2;
                    int number3;
                    int number4;

                    number1 = 0;
                    number2 = 0;
                    number3 = 0;
                    number4 = 0;
                    int Product;

                    Console.WriteLine("please enter first number");
                    number1 = int.Parse(Console.ReadLine());
                    Console.WriteLine("please enter second number");
                    number2 = int.Parse(Console.ReadLine());
                    Console.WriteLine("please enter third number");
                    number3 = int.Parse(Console.ReadLine());
                    Console.WriteLine("please enter fourth number");
                    number4 = int.Parse(Console.ReadLine());

                    Product = ProductTwoIntegers(number1, number2);
                    Console.WriteLine("Product of " + number1 + "*" + number2 + "=" + Product);

                    Product = ProductThreeIntegers(number1, number2, number3);
                    Console.WriteLine("Product of " + number1 + "*" + number2 + "*" + number3 + "=" + Product);

                    Product = ProductFourIntegers(number1, number2, number3, number4);
                    Console.WriteLine("Product of " + number1 + "*" + number2 + "*" + number3 +"*" +number4+ "=" + Product);
                    ProductDouble(1.3);
                    ProductDouble(1.5, 4.6, 1.1);
                    ProductDouble(2.4, 5.3, 1.2);
                Console.ReadLine();

                }
            }
        }
    }

