﻿/* Assignment 2
 * 
 * revision History
 * 
 * Sarav Kular, november 23, 2017
 */
using System;

namespace A2SaravKularP2
{
    class Program
    {
        public static double volume(double radius)

        {
            return (1.34 * 3.141 * radius * radius * radius);
        }
        public static double volume(double radius, double height)
        {
            return (3.141 * radius * radius * height);
        }
        public static double volume(double length, double width, 
            double height)

        {
            return (length * width * height);
        }


        static void Main(string[] args)
        {
            
            
            int shapeType;
            double radius;
            double length;
            double width;
            double height;

            radius = 0;
            length = 0;
            height = 0;
            width = 0;

            Console.WriteLine("choose any shape whose volume you want to 
                calculate");
            Console.WriteLine("enter 1 for sphere");
            Console.WriteLine("enter 2 for cylinder ");
            Console.WriteLine("enter 3 for  rectangular prism");
            
            shapeType = int.Parse(Console.ReadLine());

            switch (shapeType)
            {
                case 1 :
                    {
                        Console.WriteLine(" selected shape is sphere");
                        Console.WriteLine("please enter radius");
                        radius = double.Parse(Console.ReadLine());
                        Console.WriteLine("volume of sphere is " + volume
                            (radius));
                    }
                    break;
                    case 2:
                    {
                        Console.WriteLine(" selected shape is cylinder");
                        Console.WriteLine("please enter height");
                        height = double.Parse(Console.ReadLine());
                        Console.WriteLine("please enter radius");
                        radius = double.Parse(Console.ReadLine());
                        Console.WriteLine("volume of cylinder is " +
                            volume(radius,height));
                    }
                    break;
                case 3:
                    {
                        Console.WriteLine(" selected shape is rectangular prism");
                        Console.WriteLine("please enter length");
                        length = double.Parse(Console.ReadLine());
                        Console.WriteLine("please enter width");
                        width = double.Parse(Console.ReadLine());
                        Console.ReadLine();
                        Console.WriteLine("please enter height");
                        height = double.Parse(Console.ReadLine());
                        Console.WriteLine("volume of rectangular prism is " +
                            volume(length,width,height));
                    }
                    break;
                default:
                    Console.WriteLine("invalid entry");
                    break;

            }
            Console.Read();
        }

    }
}


