﻿/*
 * Assignment 2
 * Console application to count tution fees of students
 * Sarav Kular
 * 23rd november 2017
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2SaravKularP1
{
    class Program
    {
        static void Main(string[] args)
        {
            //initialization
            double age = 0;
            string canadian = "";
            string semester = "";
            double basetution = 0;
            double basefeestax = 0;
            double registrationfees = 0;
            double registrationfeestax = 0;
            double InternationalstudentFee = 0;
            double domesticfees = 0;
            double hst = 0;

            //international student or not
            Console.WriteLine("Are you international student? canadian/" +
                "International");
            Console.WriteLine("for canadian enter Y");
            Console.WriteLine("for international enter N");
            canadian = Console.ReadLine();

            //student's age
            Console.WriteLine("Enter your age");
            age = double.Parse(Console.ReadLine());

            if (age <= 18)
            {
                basetution = 300;

            }
            else if ((age >= 19) && (age <= 49))
            {
                basetution = 500;

            }
            else
            {
                basetution = 400;

            }
            //registered semester
            Console.WriteLine("enter first 3 letters of month of registered " +
                "semester");
            semester = Console.ReadLine();

            switch (semester)
            {
                case "jan":
                case "feb":
                case "mar":
                case "apr":
                    registrationfees = 250;
                    break;
                case "may":
                case "jun":
                case "jul":
                case "aug":
                    registrationfees = 220;
                    break;
                default:
                    registrationfees = 150;
                    break;
            }

            //calculation of fees
            if (canadian == "y")
            {
                basefeestax = basetution * 0.13;
                Console.WriteLine("base tution fees tax is :" + "$"
                    + basefeestax);
                registrationfeestax = registrationfees * 0.13;
                Console.WriteLine("registration fees tax is :" + "$"
                    + registrationfeestax);
                domesticfees = basetution + basefeestax + registrationfees
                    + registrationfeestax;
                Console.WriteLine("total domestic fees is :" + "$"
                    + domesticfees);

            }
            else
            {
                basefeestax = basetution * 0.13;
                Console.WriteLine("base tution fees tax is :" + "$" + basefeestax);
                registrationfeestax = registrationfees * 0.13;
                Console.WriteLine("registration fees tax is :" + "$"
                    + registrationfeestax);
                InternationalstudentFee = basetution + basefeestax +
                    registrationfees + registrationfeestax + 113;
                hst = basefeestax + registrationfeestax + 13;
                Console.WriteLine("HST is :" + hst);
                Console.WriteLine("total internaational student fees is :" + "$"
                    + InternationalstudentFee);


            }

            Console.ReadLine();

        }
    }
}